import requests
import os

JENKINS_URL = os.environ['JENKINS_URL']
API_TOKEN = os.environ['API_TOKEN']

def lambda_handler(event, context):
    try:
        # Construct the URL to trigger the build in Jenkins
        build_url = "{}/job/capstone-deployment/build?token={}".format(JENKINS_URL, API_TOKEN)
        
        # Send a POST request to trigger the build
        response = requests.post(build_url)
        
        # Check if the request was successful (status code 201)
        if response.status_code == 201:
            print("Build triggered successfully.")
        else:
            print("Failed to trigger build. Status code:", response.status_code)
    except Exception as e:
        print("Error:", e)
